<?php
// BASIC PHP API FOR APK ADMIN PANEL V2
// Before production use: enable HTTPS, change the admin password,
// add rate limiting/CSRF protection as appropriate for your host,
// and restrict upload size/types at the server level.

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Authorization, Content-Type');

$DATA = __DIR__.'/data.json';
$UPLOADS = __DIR__.'/uploads/';
if (!is_dir($UPLOADS)) mkdir($UPLOADS,0755,true);

$default = [
  'username'=>'admin',
  // SHA-256 of the generated setup password. Change via setup_password.php.
  'password_sha256'=>'547a4317d74046199da0cc4eff995ad80765d67e22724b894efb8304caf35b8e',
  'config'=>[
    'feature_one'=>true,
    'feature_two'=>false,
    'maintenance_mode'=>false,
    'show_updates'=>true
  ]
];
if (!file_exists($DATA)) file_put_contents($DATA,json_encode($default,JSON_PRETTY_PRINT),LOCK_EX);
$db=json_decode(file_get_contents($DATA),true);

function out($x,$code=200){http_response_code($code);echo json_encode($x);exit;}
function body(){return json_decode(file_get_contents('php://input'),true) ?: [];}
function token(){ $h=$_SERVER['HTTP_AUTHORIZATION']??''; return preg_match('/Bearer\s+(.+)/i',$h,$m)?$m[1]:''; }
function valid(){ global $db; $t=token(); if(!$t)return false; $f=__DIR__.'/sessions/'.hash('sha256',$t).'.txt'; return file_exists($f)&&file_get_contents($f)>time(); }
function require_auth(){if(!valid())out(['error'=>'Unauthorized'],401);}
function save_db(){global $DATA,$db;file_put_contents($DATA,json_encode($db,JSON_PRETTY_PRINT),LOCK_EX);}

$action=$_GET['action']??'config';

if($action==='login'){
  $b=body();
  if(($b['username']??'')!==$db['username'] || hash('sha256',(string)($b['password']??''))!==$db['password_sha256']) out(['error'=>'Invalid login'],401);
  $t=bin2hex(random_bytes(32));$s=__DIR__.'/sessions';if(!is_dir($s))mkdir($s,0755,true);
  file_put_contents($s.'/'.hash('sha256',$t).'.txt',time()+3600,LOCK_EX);
  out(['token'=>$t,'expires_in'=>3600]);
}

if($action==='config'){
  // Public endpoint used by the APK. Only configuration is exposed.
  out(['config'=>$db['config']]);
}

if($action==='register_device'){
  $b=body();
  $name=trim((string)($b['name']??''));
  $mobile=trim((string)($b['mobile']??''));
  $device=trim((string)($b['device_id']??''));
  if($name==='' || $mobile==='' || $device==='') out(['error'=>'Name, mobile and device_id are required'],400);
  $devicesFile=__DIR__.'/devices.json';
  $devices=file_exists($devicesFile)?(json_decode(file_get_contents($devicesFile),true)?:[]):[];
  $found=false;
  foreach($devices as &$d){
    if(($d['device_id']??'')===$device){$d['name']=$name;$d['mobile']=$mobile;$d['updated_at']=time();$found=true;break;}
  }
  unset($d);
  if(!$found)$devices[]=['device_id'=>$device,'name'=>$name,'mobile'=>$mobile,'authorized'=>true,'created_at'=>time(),'updated_at'=>time()];
  file_put_contents($devicesFile,json_encode($devices,JSON_PRETTY_PRINT),LOCK_EX);
  out(['ok'=>true,'verified'=>true,'device_id'=>$device]);
}

require_auth();

if($action==='set'){
  $b=body();$k=$b['key']??'';$v=$b['value']??null;
  if(!array_key_exists($k,$db['config']) || !is_bool($v))out(['error'=>'Invalid setting'],400);
  $db['config'][$k]=$v;save_db();out(['ok'=>true,'config'=>$db['config']]);
}

if($action==='upload'){
  if(!isset($_FILES['apk']))out(['error'=>'APK missing'],400);
  $name=basename($_FILES['apk']['name']);
  if(strtolower(pathinfo($name,PATHINFO_EXTENSION))!=='apk')out(['error'=>'Only APK files are allowed'],400);
  if($_FILES['apk']['error']!==UPLOAD_ERR_OK)out(['error'=>'Upload error'],400);
  $safe=preg_replace('/[^A-Za-z0-9._-]/','_',$name);
  if(!move_uploaded_file($_FILES['apk']['tmp_name'],$UPLOADS.$safe))out(['error'=>'Could not save APK'],500);
  out(['ok'=>true,'name'=>$safe,'url'=>'uploads/'.rawurlencode($safe)]);
}
out(['error'=>'Unknown action'],404);
?>