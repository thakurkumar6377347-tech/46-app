46 APK - GitHub build

This project can be built automatically by GitHub Actions.
After the files are uploaded to the repository, open Actions > Build 46 APK.
When the workflow finishes, open the run and download the 46-debug-apk artifact.
