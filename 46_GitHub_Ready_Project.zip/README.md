# 46 Android App

This is an Android Studio starter project for an app named **46** connected to:
`https://ak46.infinityfree.me/api.php`

Flow:
1. Page 1: user name
2. Page 2: mobile number + consent notice
3. Page 3: Successfully Verified after server registration

No PIN, OTP or password is collected.

The project intentionally does not implement covert SMS/call interception or forwarding. Call forwarding, where supported, must be performed through Android/carrier mechanisms with the device owner's explicit confirmation. SMS access/forwarding should only be added as a clearly disclosed, user-initiated feature and must comply with Android/Google Play policies.

Build with Android Studio and a recent Android Gradle Plugin.
